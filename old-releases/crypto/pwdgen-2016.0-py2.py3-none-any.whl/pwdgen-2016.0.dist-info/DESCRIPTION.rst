a password generator using the NightHawk Python extension


